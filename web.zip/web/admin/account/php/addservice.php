<?php
session_start();
include '../../../php/dbh.php';

$category = $_GET['category'];
$service = $_GET['service'];

$sql = "INSERT INTO services_offered (service_name, category_id) 
		VALUES ('$service', '$category')";
$result = $conn->query($sql);

$_SESSION['response'] = 'New service has been added';
header('Location: ../add_service.php');
exit();
?>
