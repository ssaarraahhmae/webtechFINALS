<?php
session_start();
include '../../../php/dbh.php';

$category = $_GET['category'];

$sql = "INSERT INTO service_categories (category_name) 
		VALUES ('$category')";
$result = $conn->query($sql);

$_SESSION['response'] = 'New category has been added';
header('Location: ../add_service.php');
exit();
?>