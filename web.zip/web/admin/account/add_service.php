<?php
	session_start();
	include '../../php/dbh.php';
	$sql = "SELECT  * FROM service_categories";
	$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Customers</title>
	<style type="text/css">
		table, th, td {
   			border: 1px solid black;
		}
	</style>
</head>
<body>
	<h1><?php echo 'Welcome ' . $_SESSION['name']; ?></h1>
	<form action="php/logout.php"><button>Logout</button></form>
	<a href= "index.php">Service Provider</a>
	<a href= "pending_sp.php">Pending SP</a>
	<a href="customer.php">Customer</a>
	<a href= "payment.php">Payments</a>
	<a href= "add_category.php">Add Category</a>
	<a href= "add_service.php">Add Service</a>

	<form action="php/addservice.php" method="GET">
		<label><b>Select Category</b></label>
		<select name="category">
			<?php
				if ($result->num_rows > 0){
					while($row = $result->fetch_assoc()) {
						echo "<option value=$row[category_id]>$row[category_name]</option>";
					}
				}
			?>
		</select>
		<br><label><b>Service Name</b></label>
		<input type="text" placeholder="Enter Service Name" name="service" required>
		<button type="submit">Add</button>
	</form>

	<?php
		if (isset($_SESSION['response'])) {
			echo $_SESSION['response'];
			unset($_SESSION['response']);
		}
	?>
</body>
</html>