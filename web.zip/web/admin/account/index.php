<?php
session_start();

?>

<!DOCTYPE HTML>
<!--
	Read Only by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>iTutor Dashboard</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1" />
		<!--[if lte IE 8]><script src="assets/js/ie/html5shiv.js"></script><![endif]-->
		<link rel="stylesheet" href="../assets/css/itutorDashboard.css" />
		<!--[if lte IE 8]><link rel="stylesheet" href="assets/css/ie8.css" /><![endif]-->
	</head>
	<style>

	/* Set a style for all buttons */
	.logout {
	    background-color: #4CAF50;
	    color: white;
	    padding: 14px 20px;
	    margin: 8px 0;
	    border: none;
	    cursor: pointer;
	    width: 100%;
	}

	button:hover {
	    opacity: 0.8;
	}

	/* Extra styles for the cancel button */
.button1 {
  border-radius: 4px;
  background-color: #4acaa8;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 300px;
    height: 100px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 50px;
}

.button1 span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button1 span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button1:hover span {
  padding-right: 50px;
    
}

.button1:hover span:after {
  opacity: 1;
  right: 0;
}
/*.buttonMenu
{
     margin: 0 auto;
     width: 500px; 
}*/
	</style>
	<body id="dbody">
       
		<!-- Header -->
        <section id="header">
        <header>
            <img src="../assets/images/logo-white.png" alt="" />
        </header>
        <div class="login-container animated fadeInRightBig">


                <form action="php/logout.php"><button class="logout">Logout</button></form>

             

            </div> <!-- .login-container -->
            
        <!-- .login-sidebar -->
				<footer>
					<ul class="icons">
						<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
						<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
						<li><a href="#" class="icon fa-envelope"><span class="label">Email</span></a></li>
					</ul>
				</footer>
			</section>




		<!-- Scripts -->
			<script src="../assets/js/jquery.min.js"></script>
			<script src="../assets/js/jquery.scrollzer.min.js"></script>
			<script src="../assets/js/jquery.scrolly.min.js"></script>
			<script src="../assets/js/util.js"></script>
			<!--[if lte IE 8]><script src="assets/js/ie/respond.min.js"></script><![endif]-->
			<script src="../assets/js/main.js"></script>
			<script>
			// Get the modal
			var modal = document.getElementById('id01');

			// When the user clicks anywhere outside of the modal, close it
			window.onclick = function(event) {
			    if (event.target == modal) {
			        modal.style.display = "none";
			    }
			}
			</script>
            
        <div class="buttonMenu">
            <button class="button1"><span>Service Provider</span></button>
            <button class="button1"><span>Pending SP </span></button><br>
            <button class="button1"><span>Costumer</span></button><br>
            <button class="button1"><span>Paymenst</span></button>
            <button class="button1"><span>Services</span></button>
        </div>        

	</body>
</html>