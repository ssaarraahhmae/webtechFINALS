<?php
	session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Payments</title>
	<style type="text/css">
		table, th, td {
   			border: 1px solid black;
		}
	</style>
</head>
<body>
	<h1><?php echo 'Welcome ' . $_SESSION['name']; ?></h1>
	<form action="php/logout.php"><button>Logout</button></form>
	<a href= "index.php">Service Provider</a>
	<a href= "pending_sp.php">Pending SP</a>
	<a href= "customer.php">Customer</a>
	<a href="payment.php">Payments</a>
	<a href= "add_category.php">Add Category</a>
	<a href= "add_service.php">Add Service</a>

	<table>
		<tr>
			<th>SPID</th>
			<th>Cust ID</th>
			<th>Date Start</th>
			<th>Date End</th>
			<th>Service</th>
		</tr>
	</table>
	
</body>
</html>