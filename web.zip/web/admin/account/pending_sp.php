<?php
	session_start();
	include '../../php/dbh.php';
	$sql = "SELECT  account_id, name, service, specialization FROM registration WHERE status = 'pending'";
	$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
	<title>Pending Service Providers</title>
	<style type="text/css">
		table, th, td {
   			border: 1px solid black;
		}
	</style>
</head>
<body>
	<h1><?php echo 'Welcome ' . $_SESSION['name']; ?></h1>
	<form action="php/logout.php"><button>Logout</button></form>
	<a href= "index.php">Service Provider</a>
	<a href="pending_sp">Pending SP</a>
	<a href= "customer.php">Customer</a>
	<a href= "payment.php">Payments</a>
	<a href= "add_category.php">Add Category</a>
	<a href= "add_service.php">Add Service</a>

	<table>
		<tr>
			<th>Name</th>
			<th>Service Offered</th>
			<th>Specialization</th>
			<th></th>
			<th></th>
		</tr>
		<?php
			if ($result->num_rows > 0){
				while($row = $result->fetch_assoc()) {
				echo '<tr>';
					echo "<td>$row[name]</td>";
					echo "<td>$row[service]</td>";
					echo "<td>$row[specialization]</td>";?>
					<form action="php/accept.php" method="GET">
						<td><button type="submit" name="accept" value="<?php print $row['account_id']; ?>">Approve</button></td>
					</form>
					<form action="php/deny.php" method="GET">
						<td><button type="submit" name="deny" value="<?php print $row['account_id']; ?>">Deny</button></td>
					</form>
					<?php
				echo '</tr>';
			}
		?>
	</table><br>
	<?php
		} else {
				echo 'No more pending requests.';
			}
	?>	
	
</body>
</html>

